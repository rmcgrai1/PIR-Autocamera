//

#ifndef LOG_H
#define LOG_H


const char
  BKP_FILENAME[16] = "_DATALOG.bkp",
  LOG_FILENAME[16] = "_DATALOG.txt",
  TMP_FILENAME[16] = "_TEMPLOG.txt";

#endif
